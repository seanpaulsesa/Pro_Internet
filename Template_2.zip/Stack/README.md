# Stack Sketch
Sketch file of design for https://themeforest.net/item/stack-admin-bootstrap-4-dashboard-template/22959011

## Font Installation
This sketch file uses 'Open Sans' as the main font. 

You are required to download and install it on your local system from https://fonts.google.com/specimen/Open+Sans